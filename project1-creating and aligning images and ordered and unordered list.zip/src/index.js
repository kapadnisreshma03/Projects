import React from "react";
import ReactDOM from "react-dom";

//const fname = "Isha";
//const lname = "Kapadnis";
//const copyright = new Date().getFullYear();

//import App from "./App";

ReactDOM.render(
  <div>
    <h1 className="heading"> list of food I like</h1>
    <div>
      <img
        className="food-img"
        src="https://i.ndtvimg.com/i/2017-12/malvani-chicken-curry_620x330_81514354104.jpg"
      ></img>
      <img
        className="food-img"
        src="https://i1.wp.com/kalimirchbysmita.com/wp-content/uploads/2019/10/Chole-Bhature-01.jpg?resize=1024%2C682&ssl=1"
      ></img>
    </div>

    <ul>
      <li> Chiken Curry</li>
      <li> Chole Bhature</li>
      <li> Sandwitches </li>
    </ul>
    <h1> list of food I don't like </h1>
    <ol>
      <li> Chai </li>
      <li> Milk </li>
      <li> Bengali Sweets </li>
    </ol>
  </div>,
  document.getElementById("root")
);
/*
ReactDOM.render(
  <div>
    <h1> Created by  {fname + " " + lname}</h1>
    <h4> Your lucky number is {Math.floor(Math.random()*10)}</h4>
    <p> copyright {copyright}</p>
  </div>,
  document.getElementById("root"));

*/
