import React from "react";
import ReactDOM from "react-dom";

const d = new Date();
const currentTime = d.getTime();

let greeting;

const customStyle = {
  color: " "
};

if (currentTime < 12) {
  greeting = "Good morning";
  customStyle.color = "red";
} else if (12 > currentTime < 18) {
  greeting = "Good Afternoon";
  customStyle.color = "green";
} else {
  greeting = "Good night";
  customStyle.color = "yellow";
}

//import App from "./App";

ReactDOM.render(
  <h1 className="heading" style={customStyle}>
    {" "}
    {greeting}
  </h1>,
  document.getElementById("root")
);
