import React from "react";

function heading(){
  return <h1> foods list</h1>;

}
export default heading