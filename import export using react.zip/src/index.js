import React from "react";
import ReactDOM from "react-dom";
import Heading from "./heading";

//import App from "./App";

ReactDOM.render(
  <div>
    <Heading />
    <ul>
      <li>ice cream</li>
      <li>salad</li>
      <li>cookie</li>
    </ul>
  </div>,
  document.getElementById("root")
);
